# ${{ values.repoName }}

Python Flask app. Build and run:

```sh
docker build -t ${{ values.dockerImage }} .
docker run -p 8080:8080 ${{ values.dockerImage }}
```