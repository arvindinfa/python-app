# {{ name }}

{{ description }}

## Running Locally

```bash
pip install -r requirements.txt
python app.py
```

## Deploy to Kubernetes

- Update image in k8s/deployment.yaml
- `kubectl apply -f k8s/`

## CI/CD

- See `.github/workflows/ci-cd.yaml`
