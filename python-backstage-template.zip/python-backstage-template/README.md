# Backstage Python K8s Template

This Backstage template will scaffold a Python app with:
- GitHub Actions CI/CD
- Kubernetes deployment
- Dockerfile & Helm-ready manifest

See `/skeleton` for the project skeleton.

Register this template with your Backstage scaffolder!
